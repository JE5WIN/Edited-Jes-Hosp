<footer>
				<div class="footer-inner">
					<div class="pull-left">
						&copy; <span class="current-year"></span><span class="text-bold text-uppercase"> Jes</span>. <span>Developed by Jeswin</span>
					</div>
					<div class="pull-right">
						<span class="go-top"><i class="ti-angle-up"></i></span>
					</div>
					
					<div class="col-md-12 col-sm-12 col-xs-12 headings">

</div>
					<div class="row2 col-md-12 col-sm-12 col-xs-12 no-padding">
<div class="col-md-3 col-sm-3 col-xs-3 heads-img"><img alt="" src="https://www.manipalhospitals.com/assets/images/footer/NABL.JPG" height="60" width="60"></div>
<div class="col-md-3 col-sm-3 col-xs-3 heads-img"><img alt="" src="https://www.manipalhospitals.com/assets/images/footer/nabh.png" height="60" width="60"></div>
</div>
				</div>
			</footer>